package Sub::App2;
use strict;
use warnings;
use Dancer2;

1;
