layout:<%foo%>
content:<% content %>

